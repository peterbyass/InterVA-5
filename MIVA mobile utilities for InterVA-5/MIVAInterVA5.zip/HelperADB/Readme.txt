DO NOT DELETE THIS FOLDER

adb.exe from Android Platform-tools

The contents of this folder are required in order to execute all the provided .bat (batch) scripts on a Windows machine