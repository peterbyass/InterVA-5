Helper .bat (batch) script for downloading all ODK Collect saved forms from a device using debugging mode.

Please see AppPackagesAPK\GuidanceDocumentOnInstallingAPKs.docx to find instructions on how to enable USB debugging and connecting to your device using these batch scripts.

Once all forms data is downloaded, they are stored in pulledData\ folder

These scripts only work on Windows.

